package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Student;
import com.example.repository.StudentRepository;
@Service
public class StudentServiceImpl {
	
	private StudentRepository repository ;

	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return repository.save(student);
	}

	public List<Student> getStudentList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	public Student getStudentById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	public void deleteStudentById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	
	

}
