package com.example.service;

import java.util.List;

import com.example.entity.Student;

public interface StudentService {
	Student saveCertificate(Student certificate);

	List<Student> getStudentList();

	Student getStudentById(Long id);

	void deleteStudentById(Long id);

}
